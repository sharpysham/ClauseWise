import { useState } from "react";
function App() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [progress, setProgress] = useState(0);
  const getRiskColor = (score) => {
    if (score <= 3) return "#16a34a"; // green
    if (score <= 6) return "#ca8a04"; // yellow
    return "#dc2626"; // red
  };
  const resetApp = () => {
    setResult(null);
    setLoading(false);
  };
  return (
    <div style={{ ...styles.container, ...styles.page }}>
      <div style={styles.bgBlob1}></div>
      <div style={styles.bgBlob2}></div>
      <div style={styles.header}>
        <div style={styles.logoWrapper}>
          <div style={styles.paper}></div>
          <div style={styles.magnifier}></div>
        </div>
        <h1 style={styles.brand}>ClauseWise</h1>
        <p style={styles.tagline}>
          See contract risks before they cost you.
        </p>
      </div>
      <h1 style={styles.title}>
        Understand contract risks before you sign
      </h1>

      <p style={styles.subtitle}>
        Upload your contract. We explain hidden risks in plain English.
      </p>
      {!loading && !result && (
        <div
          style={styles.uploadBox}
          onClick={() => document.getElementById("fileInput").click()}
          onMouseEnter={(e) => {
            e.currentTarget.style.borderColor = "#6366f1";
            e.currentTarget.style.transform = "translateY(-4px) scale(1.01)";
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.borderColor = "#94a3b8";
            e.currentTarget.style.transform = "translateY(0) scale(1)";
          }}
        >
          <input
            type="file"
            accept=".pdf"
            style={{ display: "none" }}
            id="fileInput"
            onChange={() => {
              setLoading(true);
              setProgress(0);

              let value = 0;
              const interval = setInterval(() => {
                value += 10;
                setProgress(value);

                if (value >= 100) {
                  clearInterval(interval);

                  setResult({
                    overall_risk_score: 7,
                    flagged_clauses: [
                      {
                        risk_type: "Auto-Renewal",
                        plain_explanation:
                          "Your contract renews automatically unless you cancel 30 days before the end date.",
                        financial_impact:
                          "You may be charged for another year even if you stop using the service."
                      },
                      {
                        risk_type: "Early Termination Penalty",
                        plain_explanation:
                          "If you exit the contract early, you must pay the remaining contract value.",
                        financial_impact:
                          "Early exit could cost up to ₹50,000 depending on remaining months."
                      }
                    ]
                  });

                  setLoading(false);
                }
              }, 300);
            }}
          />
          <p style={styles.uploadText}>Upload contract PDF</p>
        </div>
      )}
      {loading && (
        <div style={styles.analyzingBox}>
          <p style={styles.loading}>Analyzing contract…</p>

          <div style={styles.progressBar}>
            <div
              style={{
                ...styles.progressFill,
                width: `${progress}%`
              }}
            />
          </div>

          <p style={styles.progressText}>{progress}%</p>
        </div>
      )}
      {result && (
        <div style={styles.dashboard}>
          <h2
            style={{
              ...styles.score,
              color: getRiskColor(result.overall_risk_score)
            }}
          >
            Risk Score: {result.overall_risk_score}/10
          </h2>

          {result.flagged_clauses.map((item, index) => (
            <div
              key={index}
              style={{
                ...styles.card,
                ...styles.cardAnimated,
                animationDelay: `${index * 0.15}s`
              }}
            >
              <h3 style={styles.cardTitle}>{item.risk_type}</h3>
              <p>{item.plain_explanation}</p>
              <p style={styles.impact}>⚠️ {item.financial_impact}</p>
            </div>
          ))}

          <button style={styles.resetBtn} onClick={resetApp}>
            Upload another contract
          </button>
        </div>
      )}


      <p style={styles.trust}>
        We don’t store your contracts. Analysis happens locally.
      </p>
    </div>
  );
}

const styles = {
  container: {
    minHeight: "100vh",
    background: "#f9fafb",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    padding: "20px",
    textAlign: "center",
    position: "relative",
    overflow: "hidden",
  },
  title: {
    fontSize: "36px",
    fontWeight: "700",
    marginBottom: "12px",
    color: "#0f172a"
  },
  subtitle: {
    fontSize: "18px",
    color: "#475569",
    maxWidth: "600px",
    marginBottom: "40px"
  },
  uploadBox: {
    background: "rgba(255, 255, 255, 0.65)",
    backdropFilter: "blur(14px)",
    WebkitBackdropFilter: "blur(14px)",
    borderRadius: "18px",
    padding: "48px",
    width: "380px",
    cursor: "pointer",
    border: "1px solid rgba(99, 102, 241, 0.25)",
    boxShadow: "0 20px 40px rgba(79, 70, 229, 0.18)",
    transition: "all 0.35s ease"
  },
  uploadText: {
    marginTop: "12px",
    color: "#64748b"
  },
  trust: {
    marginTop: "24px",
    fontSize: "13px",
    color: "#94a3b8"
  },
  loading: {
    fontSize: "18px",
    fontWeight: "500",
    color: "#6366f1",
    marginTop: "40px"
  },
  dashboard: {
    marginTop: "40px",
    maxWidth: "900px",
    width: "90%"
  },
  score: {
    fontSize: "28px",
    fontWeight: "700",
    color: "#dc2626",
    marginBottom: "24px"
  },
  card: {
    background: "#ffffff",
    borderRadius: "12px",
    padding: "20px",
    marginBottom: "16px",
    boxShadow: "0 10px 20px rgba(0,0,0,0.05)"
  },
  cardTitle: {
    fontSize: "18px",
    fontWeight: "600",
    marginBottom: "8px"
  },
  impact: {
    marginTop: "8px",
    color: "#b91c1c",
    fontWeight: "500"
  },
  page: {
    animation: "fadeIn 0.8s ease forwards"
  },
  cardAnimated: {
    animation: "slideUp 0.5s ease forwards",
    opacity: 0
  },
  resetBtn: {
    marginTop: "30px",
    padding: "12px 20px",
    borderRadius: "10px",
    border: "none",
    background: "#6366f1",
    color: "#ffffff",
    fontSize: "15px",
    fontWeight: "600",
    cursor: "pointer",
    transition: "all 0.25s ease"
  },
  header: {
    marginBottom: "40px"
  },
  logo: {
    fontSize: "42px",
    marginBottom: "8px"
  },
  brand: {
    fontSize: "42px",
    fontWeight: "700",
    color: "#4f46e5"
  },
  tagline: {
    marginTop: "8px",
    fontSize: "18px",
    color: "#475569"
  },
  bgBlob1: {
    position: "absolute",
    width: "420px",
    height: "420px",
    background: "#c7d2fe",
    borderRadius: "50%",
    top: "-120px",
    left: "-120px",
    filter: "blur(120px)",
    zIndex: -1
  },
  bgBlob2: {
    position: "absolute",
    width: "420px",
    height: "420px",
    background: "#e9d5ff",
    borderRadius: "50%",
    bottom: "-120px",
    right: "-120px",
    filter: "blur(120px)",
    zIndex: -1
  },
  logoWrapper: {
    position: "relative",
    width: "64px",
    height: "64px",
    margin: "0 auto 16px auto"
  },

  paper: {
    width: "40px",
    height: "52px",
    background: "#ffffff",
    borderRadius: "6px",
    position: "absolute",
    top: "6px",
    left: "6px",
    boxShadow: "0 6px 18px rgba(0,0,0,0.15)"
  },

  magnifier: {
    width: "26px",
    height: "26px",
    borderRadius: "50%",
    border: "4px solid #7c3aed",
    position: "absolute",
    bottom: "6px",
    right: "2px"
  },
  logo: {
    width: "56px",
    height: "56px",
    borderRadius: "14px",
    background: "linear-gradient(135deg, #6366f1, #a855f7)",
    color: "#ffffff",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontWeight: "700",
    fontSize: "20px",
    margin: "0 auto 12px auto",
    boxShadow: "0 10px 25px rgba(99,102,241,0.35)"
  },
  analyzingBox: {
    marginTop: "30px",
    width: "380px",
    textAlign: "center"
  },

  progressBar: {
    height: "10px",
    width: "100%",
    background: "rgba(99,102,241,0.2)",
    borderRadius: "999px",
    overflow: "hidden",
    marginTop: "12px"
  },

  progressFill: {
    height: "100%",
    background: "linear-gradient(90deg, #6366f1, #a855f7)",
    transition: "width 0.3s ease"
  },

  progressText: {
    marginTop: "8px",
    fontSize: "14px",
    color: "#4f46e5",
    fontWeight: "600"
  },
};

export default App;